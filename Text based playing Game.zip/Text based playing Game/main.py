class Room:
    def __init__(self, name, description):
        self.name = name
        self.description = description
        self.items = []
        self.enemies = []
        self.connected_rooms = {}

    def add_item(self, item):
        self.items.append(item)

    def add_enemy(self, enemy):
        self.enemies.append(enemy)

    def connect_room(self, direction, room):
        self.connected_rooms[direction] = room

    def get_description(self):
        desc = f"{self.name}\n{self.description}\n"
        if self.items:
            desc += "Items here: " + ", ".join(item.name for item in self.items) + "\n"
        if self.enemies:
            desc += "Enemies here: " + ", ".join(enemy.name for enemy in self.enemies) + "\n"
        return desc


class Item:
    def __init__(self, name, description):
        self.name = name
        self.description = description


class Enemy:
    def __init__(self, name, health):
        self.name = name
        self.health = health


class Player:
    def __init__(self, name):
        self.name = name
        self.health = 100
        self.inventory = []
        self.current_room = None

    def move(self, direction):
        if direction in self.current_room.connected_rooms:
            self.current_room = self.current_room.connected_rooms[direction]
            print(f"You move to the {self.current_room.name}.")
        else:
            print("You can't go that way.")

    def take(self, item_name):
        for item in self.current_room.items:
            if item.name == item_name:
                self.inventory.append(item)
                self.current_room.items.remove(item)
                print(f"You take the {item.name}.")
                return
        print("Item not found.")

    def fight(self, enemy_name):
        for enemy in self.current_room.enemies:
            if enemy.name == enemy_name:
                print(f"You fight the {enemy.name}!")
                enemy.health -= 20
                if enemy.health <= 0:
                    print(f"You defeated the {enemy.name}!")
                    self.current_room.enemies.remove(enemy)
                else:
                    print(f"The {enemy.name} has {enemy.health} health left.")
                return
        print("Enemy not found.")


# Create rooms
room1 = Room("Entrance Hall", "A large hall with a grand staircase.")
room2 = Room("Library", "A room filled with dusty books.")
room3 = Room("Armory", "A room filled with ancient weapons.")

# Connect rooms
room1.connect_room("north", room2)
room2.connect_room("south", room1)
room2.connect_room("east", room3)
room3.connect_room("west", room2)

# Create items
sword = Item("Sword", "A sharp-looking sword.")
shield = Item("Shield", "A sturdy shield.")

# Add items to rooms
room3.add_item(sword)
room1.add_item(shield)

# Create enemies
goblin = Enemy("Goblin", 50)

# Add enemies to rooms
room2.add_enemy(goblin)

# Create player
player = Player("Hero")

# Place player in the initial room
player.current_room = room1

# Game loop
while True:
    print(player.current_room.get_description())
    command = input("> ").strip().lower().split()

    if not command:
        continue

    action = command[0]
    if action == "go":
        if len(command) > 1:
            player.move(command[1])
        else:
            print("Go where?")
    elif action == "take":
        if len(command) > 1:
            player.take(command[1])
        else:
            print("Take what?")
    elif action == "fight":
        if len(command) > 1:
            player.fight(command[1])
        else:
            print("Fight whom?")
    elif action == "quit":
        print("Thanks for playing!")
        break
    else:
        print("Unknown command.")
